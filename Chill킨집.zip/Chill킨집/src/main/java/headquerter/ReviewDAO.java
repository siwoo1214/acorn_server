package headquerter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ReviewDAO {
	String driver = "oracle.jdbc.driver.OracleDriver" ;
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String user="system";
	String password="1234";
	
	private Connection dbCon() {		
		Connection con = null;
		try {
			Class.forName(driver);
			con =DriverManager.getConnection(url, user, password);
			if( con != null) { System.out.println("db ok");}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<Reviews> allReviews(){
		ArrayList<Reviews> list = new ArrayList<>();
		Connection con = dbCon();
		String sql = "select * from Reviews";
		
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				String r_code = rs.getString(1);
				String id = rs.getString(2);
				String detail = rs.getString(3);
				
				list.add(new Reviews(r_code,id,detail)); 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	//얘가 지금 하던거임 04/16버전
	public void writeReview(Reviews review) {
		Connection con = dbCon();
		String sql = "insert into reviews values(?,?,?,?)"
	}
	
	public static void main(String[] args) {
		ReviewDAO a = new ReviewDAO();
		ArrayList<Reviews> list = a.allReviews();
		for(Reviews b : list) {
			System.out.println(b);
		}
	}
}
