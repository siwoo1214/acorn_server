package headquerter;

public class Reviews {
	String r_code;
	String id;
	String detail;
	
	public Reviews(String r_code, String id, String detail) {
		this.r_code = r_code;
		this.id = id;
		this.detail = detail;
	}
	public String getR_code() {
		return r_code;
	}
	public String getId() {
		return id;
	}
	public String getDetail() {
		return detail;
	}
	
	@Override
	public String toString() {
		return "Reviews [r_code=" + r_code + ", id=" + id + ", detail=" + detail + "]";
	}
}
